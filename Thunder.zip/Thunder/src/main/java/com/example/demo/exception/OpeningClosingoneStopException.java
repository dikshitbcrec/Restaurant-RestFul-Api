package com.example.demo.exception;

public class OpeningClosingoneStopException extends RuntimeException {
	
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 7544328743505452666L;

	public OpeningClosingoneStopException(String message)
	{
		super(message);
	}

}
