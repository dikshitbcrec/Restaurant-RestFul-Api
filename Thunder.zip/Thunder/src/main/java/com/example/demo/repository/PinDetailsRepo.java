package com.example.demo.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.example.demo.model.PinDetails;

public interface PinDetailsRepo extends JpaRepository<PinDetails, Integer> {

	
	
	
}
